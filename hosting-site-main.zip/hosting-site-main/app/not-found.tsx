import Custom404 from "@/components/custom-404"

export default function NotFound() {
  return <Custom404 />
}